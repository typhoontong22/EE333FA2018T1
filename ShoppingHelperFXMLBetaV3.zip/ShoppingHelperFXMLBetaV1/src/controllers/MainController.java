/*
 * File: MainController.java
 * Author: Tyler Pierce tpierce7@uab.edu
 * Assignment:  ShoppingHelperFXML - EE333 Fall 2018
 * Vers: 1.0.0 12/05/2018 ATP - initial coding
 *
 * Credits:  (if any for sections of code)
 */
 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import java.awt.Desktop;
import java.io.File;
import java.nio.file.Path;
import javafx.event.*;
import javafx.fxml.*;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;

/**
 *
 * @author Tyler Pierce tpierce7@uab.edu
 */
public class MainController {

    @FXML
    private ComboBox selectStoreComboBox;
    @FXML
    private Button viewInventoryButton;
    @FXML
    private Button importListButton;
    @FXML
    private Button createListButton;
    @FXML
    private Button goButton;

    final FileChooser fileChooser = new FileChooser();

    private static Desktop desktop = Desktop.getDesktop();

    
    

    
    
    // private final AppModel model;

    // Event listener on ComboBox[#selectStoreComboBox].onAction
    @FXML
    public void selectStore(ActionEvent event) {
        //Code for storing the selected choice and enabling buttons
      AppModel.setStoreName( selectStoreComboBox.getValue().toString() + ".txt");
      
      if(AppModel.operatingSystem.contains("Windows")){
        AppModel.setStoreFile(".//store//"+ AppModel.getStoreName()); 
        }else if(AppModel.operatingSystem.contains("Mac")){
        AppModel.setStoreFile(".\\store\\"+ AppModel.getStoreName());      
        }
    }

    // Event listener on Button[#viewInventoryButton].onAction
    @FXML
    public void viewInventory(ActionEvent event) {
        AppModel.setPane(1);
    }

    // Event listener on Button[#importListButton].onAction
    @FXML
    public void importList(ActionEvent event) {
        //Code that pulls up file explorer

        File file = fileChooser.showOpenDialog(importListButton.getScene().getWindow());
        if (file != null) {
            openFile(file);
        }
        AppModel.setPane(1);
    }

    // Event listener on Button[#createListButton].onAction
    @FXML
    public void createList(ActionEvent event) {
        //Just move to shoppingListPage
        AppModel.setPane(1);
    }

    // Event listener on Button[#goButton].onAction
    @FXML
    public void go(ActionEvent event) {
        // ??? Not really sure what this is supposed to do...
        
        AppModel.setPane(2);

    }

    public void initialize() {
        // All the junk like disabling and enabling buttons and stuff I guess
        selectStoreComboBox.setPromptText("Please Select Store...  ");
        //Populate
        ObservableList<String> store = FXCollections.observableArrayList();
        
        if(AppModel.operatingSystem.contains("Windows")){
        AppModel.setStoreFile(".//store");    
        }else if(AppModel.operatingSystem.contains("Mac")){
        AppModel.setStoreFile(".\\store");        
        }
        
        File[] storeFiles = AppModel.getStoreFile().listFiles();

        for (int i = 0; i < storeFiles.length; i++) {
            if (storeFiles[i].isFile()) {
               int i2 = storeFiles[i].getName().indexOf(".");
                
                store.add(storeFiles[i].getName().substring(0, i2));
            } 
        }
        selectStoreComboBox.setItems(store);
    }

    public void openFile(File file) {

        AppModel.setListFile(file);
        AppModel.setListName(file.getName());
    }


}
