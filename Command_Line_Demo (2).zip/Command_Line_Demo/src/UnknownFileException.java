/*
 * File: MissingComponentException.java
 * Author: Gavin Matthews gm97@uab.edu
 * Assignment:  gm97-P3 - EE333 Fall 2018
 * Vers: 1.0.0 10/11/2018 GAM - initial coding
 *
 * Credits:  (if any for sections of code)
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Gavin Matthews gm97@uab.edu
 */
public class UnknownFileException extends Exception {
    
    public UnknownFileException(String msg){
        
        super(msg);
        
    }

}
