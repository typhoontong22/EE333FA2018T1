/*
 * File: Command_Line_Demo.java
 * Author: Gavin Matthews gm97@uab.edu
 * Assignment:  Command_Line_Demo - EE333 Fall 2018
 * Vers: 1.0.0 11/01/2018 GAM - initial coding
 *
 * Credits:  (if any for sections of code)
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.util.Scanner;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import org.jawk.*;
/**
 *
 * @author Gavin Matthews gm97@uab.edu
 */
public class Command_Line_Demo {

    /**
     * @param args the command line arguments
     * @throws UnknownFileException can not find file supplied
     */
    public static void main(String[] args) throws UnknownFileException {
        // TODO code application logic here
         if ((args.length == 1) && ("/i".equals(args[0]))){
             
            Scanner scanner = new Scanner(System.in);
            
            System.out.println("Which store would you like to select? ");
            String store = scanner.next();
            if (!(store.contains(".txt"))){
                store = store + ".txt";
            }
            System.out.println("What is your grocery list?");
            String list = scanner.next();
            if (!(list.contains(".txt"))){
                list = list + ".txt";
            }
            File storeFile = new File(store);
            File listFile = new File(list);
            if ((storeFile.isFile() == false) || (listFile.isFile() == false)){
                throw new UnknownFileException("Unknown store file please provide a valid file");
            }
            String output = "";
            Command_Line_Demo commandLineDemo = new Command_Line_Demo();
            commandLineDemo.runAwk(store, list,output);
           
  
         }else if ((args.length == 2) && ("/i".equals(args[0])) && ("/o".equals(args[1]))){
         Scanner scanner = new Scanner(System.in);
            System.out.println("Which store would you like to select? ");
            String store = scanner.next();
            if (!(store.contains(".txt"))){
                store = store + ".txt";
            }
            System.out.println("What is your grocery list?");
            String list = scanner.next();
            if (!(list.contains(".txt"))){
                list = list + ".txt";
            }
            System.out.println("What is your output file?");
            String output = scanner.next();
            if (!(output.contains(".txt"))){
                output = output + ".txt";
            }
            File storeFile = new File(store);
            File listFile = new File(list);
            if ((storeFile.isFile() == false) || (listFile.isFile() == false)){
                throw new UnknownFileException("Unknown store file please provide a valid file");
            }
            Command_Line_Demo commandLineDemo = new Command_Line_Demo();
            commandLineDemo.runAwk(store, list,output);
         }else if ((args.length == 3) && ("/p".equals(args[0]))){
                    
            
            
            String store = args[1];
            if (!(store.contains(".txt"))){
                store = store + ".txt";
            }
            String list = args[2];
            if (!(list.contains(".txt"))){
                list = list + ".txt";
            }
            File storeFile = new File(store);
            File listFile = new File(list);
            if ((storeFile.isFile() == false) || (listFile.isFile() == false)){
                throw new UnknownFileException("Unknown store file please provide a valid file");
            }
            String output = "";
            Command_Line_Demo commandLineDemo = new Command_Line_Demo();
            commandLineDemo.runAwk(store, list,output);
         }else if ((args.length == 5) && ("/p".equals(args[0])) && ("/o".equals(args[1]))){

            String store = args[2];
            if (!(store.contains(".txt"))){
                store = store + ".txt";
            }
            String list = args[3];
            if (!(list.contains(".txt"))){
                list = list + ".txt";
            }
            String output = args[4];
            if (!(output.contains(".txt"))){
                output = output + ".txt";
            }
            File storeFile = new File(store);
            File listFile = new File(list);
            if ((storeFile.isFile() == false) || (listFile.isFile() == false)){
                throw new UnknownFileException("Unknown store file please provide a valid file");
            }
            Command_Line_Demo commandLineDemo = new Command_Line_Demo();
            commandLineDemo.runAwk(store, list,output);
         }else{
            System.out.println("-------Help mode-------");
            System.out.println("/i - interactive mode");
            System.out.println("/i /o - interactive mode with output filename");
            System.out.println("/p - parameter mode requires 2 input filenames");
            System.out.println("    after the mode selection.");
            System.out.println("/p /o - parameter mode requires 2 input filenames");
            System.out.println("   and 1 output filename after the mode selection.");
        }
                
    }
    
        private void runAwk(String store,String list, String output){
        String s;
        String s2;
        String stringOutput;
        ArrayList<String> stringLog1;
        ArrayList<String> stringLog2;
        stringLog1 = new  ArrayList<>();
        stringLog2 = new  ArrayList<>();
        // cmd /c (or command /c) is needed for internal commands
        // but not for external commands like ping
        // String command = "cmd /c dir";

        // Summer 2004 EE333 students report that the Engineering Lab
        // computers are locked down in such a way as to prevent
        // proper execution of ANY command without running it within
        // the cmd /c shell .
        try{
            
        if (output.length() == 0){
        String command = "awk {print}".concat(" " + store)  ; 
        String command2 = "awk {print}".concat(" " + list)  ;
        Runtime rt = Runtime.getRuntime();

        Process p = rt.exec( command );
        Process p2 = rt.exec(command2);
        BufferedReader br = new BufferedReader(
                            new InputStreamReader( p.getInputStream() ) );
        BufferedReader br2 = new BufferedReader(
                            new InputStreamReader( p2.getInputStream() ) );
        
        while ( ( s = br.readLine() ) != null )
            
            stringLog1.add(s);
        while ( ( s2 = br2.readLine() ) != null )
            stringLog2.add(s2);
        }
        if (output.length() > 0){
        String command = ("awk {print}" + " " + store)  ; 
        String command2 = ("awk {print}" + " " + list)  ;
      
        Runtime rt = Runtime.getRuntime();

        Process p = rt.exec( command );
        Process p2 = rt.exec(command2);
        BufferedReader br = new BufferedReader(
                            new InputStreamReader( p.getInputStream() ) );
        BufferedReader br2 = new BufferedReader(
                            new InputStreamReader( p2.getInputStream() ) );
        
        
       
       
        while ( ( s = br.readLine() ) != null ){
           
         //  fw.write(s);
         //  fw.write(System.lineSeparator());
           stringLog1.add(s);
           
        }
        // System.out.println(stringLog1);
        
        while ( ( s2 = br2.readLine() ) != null ){
          //  fw.write(s2);
         //  fw.write(System.lineSeparator());
            stringLog2.add(s2);
            
        }
      //  System.out.println(stringLog2);
        
        }
        }
        
        
         catch(Exception e){
             System.out.println(e.getMessage());
             System.out.println(e.getLocalizedMessage());
                 }
         boolean[][] contains = new boolean[stringLog1.size()][stringLog2.size()] ;
         int listCount=0;
         String[] strings1;
         strings1 = new String[10];
         String[] strings2;
         strings2 = new String[10];
         double total = 0.0;
         int j =0;
         boolean found;
         for (int i = 0; i < stringLog1.size(); i++){
             
              found = false;
             
             for ( int i2 =0; i2<stringLog2.size();i2++){
                 strings2 = stringLog2.get(i2).split(" ");
           contains[i][i2] = stringLog1.get(i).contains(strings2[0]);
           if (contains[i][i2] == true){
               listCount++;
               // System.out.println(stringLog1.get(i));
               strings1 = stringLog1.get(i).split(" ");
               double x = Double.parseDouble(strings1[3]);
               
               
               double y = Double.parseDouble(strings2[1]);
               double item = x*y;
               total = total  + item;
                stringOutput = ("Item: " + strings2[0] +" Aisle: " + strings1[1] + " Quantity in stock: " 
                       +strings1[2]+" Quantity requested: "+ strings2[1]+" Cost per unit: " + strings1[3]+ " Price for listed request: " + item
                       + " Running Total: " + total );
                if(output.isEmpty() == true){
                 // System.out.println(stringOutput);
               }else{
                    
                   try{
                        FileWriter fw;
                       File outputFile = new File(output);
                       if( j == 0){
                       fw = new FileWriter(output);    
                       fw.write(stringOutput);
                       j++;
                       }
                      
                       fw = new FileWriter(output,true);
                       
                      
                        fw.append(stringOutput);
                        fw.append(System.lineSeparator());
                   
                    
                    
                   
                       
                  fw.close();
                   }catch(Exception e){
                       
                   
                   }
             }
              
               }
              
           }
           
            
                   
                   
         }
         
      //System.out.println(total);
         if(stringLog2.size() == listCount){
           //  System.out.println("All items are in store");
         }else{
          //   System.out.println("All items are not in store");
         } 
     
         
         

     
     

}
}