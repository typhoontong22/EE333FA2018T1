/*
 * File: storeController.java
 * Author: Tyler Pierce tpierce7@uab.edu
 * Assignment:  ShoppingHelperFXML - EE333 Fall 2018
 * Vers: 1.0.0 12/05/2018 ATP - initial coding
 *
 * Credits:  (if any for sections of code)
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import javafx.event.*;
import javafx.fxml.*;
import javafx.scene.control.*;
import javafx.scene.shape.Circle;
import javafx.scene.text.*;

/**
 *
 * @author Tyler Pierce tpierce7@uab.edu
 */
public class storeController {

  //  private final AppModel model;
    
    
    @FXML
    private Circle aisleOneCircle,aisleTwoCircle,aisleThreeCircle,aisleFourCircle,aisleFiveCircle,aisleSixCircle;
    @FXML
    private Text aisleOneText,aisleTwoText,aisleThreeText,aisleFourText,aisleFiveText,aisleSixText;
    @FXML
    private Button closeButton;
    @FXML
    private Button helpButton;
   
    /*
    public storeController(AppModel model){
        this.model = model;
    }
    */
   
    // Event listener on Button[#closeButton].onAction
    @FXML
    public void close(ActionEvent event){
        // Code that closes out the program I guess...
        AppModel.setPane(0);
    }
    
    // Event listener on Button[#helpButton].onAction
    @FXML
    public void help(ActionEvent event){
        // Code that pops up a help window
        Boolean[] b1 = AppModel.getAisle();
        
        if (b1[0] == true){
        aisleOneCircle.setVisible(true);
        aisleOneText.setVisible(true);
        }
        if (b1[1] == true){
        aisleTwoCircle.setVisible(true);
        aisleTwoText.setVisible(true);
        }
        if (b1[2] == true){
        aisleThreeCircle.setVisible(true);
        aisleThreeText.setVisible(true);
        }
        if (b1[3] == true){
        aisleFourCircle.setVisible(true);
        aisleFourText.setVisible(true);
        }
        if (b1[4] == true){
        aisleFiveCircle.setVisible(true);
        aisleFiveText.setVisible(true);
        }
        if (b1[5] == true){
        aisleSixCircle.setVisible(true);
        aisleSixText.setVisible(true);
        }
     
    }
    
    public void initialize(){
        // All the junk like disabling and enabling buttons and stuff I guess
        

    
     
    }
    
}
