package controllers;

/*
 * File: runAwk.java
 * Author: Gavin Matthews gm97@uab.edu
 * Assignment:  runAwk - EE333 Fall 2018
 * Vers: 1.0.0 11/01/2018 GAM - initial coding
 *
 * Credits:  (if any for sections of code)
 */
 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.util.Scanner;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 *
 * @author Gavin Matthews gm97@uab.edu
 */
public class runAwk {
    Boolean[] b1;

    /*
    public static void main(String[] args) throws UnknownFileException {
        // TODO code application logic here
        if ((args.length == 1) && ("/i".equals(args[0]))) {

            Scanner scanner = new Scanner(System.in);

            System.out.println("Which store would you like to select? ");
            String store = scanner.next();
            if (!(store.contains(".txt"))) {
                store = store + ".txt";
            }
            System.out.println("What is your grocery list?");
            String list = scanner.next();
            if (!(list.contains(".txt"))) {
                list = list + ".txt";
            }
            File storeFile = new File(store);
            File listFile = new File(list);
            if ((storeFile.isFile() == false) || (listFile.isFile() == false)) {
                throw new UnknownFileException("Unknown file please provide a valid file");
            }
            String output = "";
            runAwk commandLineDemo = new runAwk();
            commandLineDemo.runAwk(store, list, output);

        } else if ((args.length == 2) && ("/i".equals(args[0])) && ("/o".equals(args[1]))) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Which store would you like to select? ");
            String store = scanner.next();
            if (!(store.contains(".txt"))) {
                store = store + ".txt";
            }
            System.out.println("What is your grocery list?");
            String list = scanner.next();
            if (!(list.contains(".txt"))) {
                list = list + ".txt";
            }
            System.out.println("What is your output file?");
            String output = scanner.next();
            if (!(output.contains(".txt"))) {
                output = output + ".txt";
            }
            File storeFile = new File(store);
            File listFile = new File(list);
            if ((storeFile.isFile() == false) || (listFile.isFile() == false)) {
                throw new UnknownFileException("Unknown file please provide a valid file");
            }
            runAwk commandLineDemo = new runAwk();
            commandLineDemo.runAwk(store, list, output);
        } else if ((args.length == 3) && ("/p".equals(args[0]))) {

            String store = args[1];
            if (!(store.contains(".txt"))) {
                store = store + ".txt";
            }
            String list = args[2];
            if (!(list.contains(".txt"))) {
                list = list + ".txt";
            }
            File storeFile = new File(store);
            File listFile = new File(list);
            if ((storeFile.isFile() == false) || (listFile.isFile() == false)) {
                throw new UnknownFileException("Unknown file please provide a valid file");
            }
            String output = "";
            runAwk commandLineDemo = new runAwk();
            commandLineDemo.runAwk(store, list, output);
        } else if ((args.length == 5) && ("/p".equals(args[0])) && ("/o".equals(args[1]))) {

            String store = args[2];
            if (!(store.contains(".txt"))) {
                store = store + ".txt";
            }
            String list = args[3];
            if (!(list.contains(".txt"))) {
                list = list + ".txt";
            }
            String output = args[4];
            if (!(output.contains(".txt"))) {
                output = output + ".txt";
            }
            File storeFile = new File(store);
            File listFile = new File(list);
            if ((storeFile.isFile() == false) || (listFile.isFile() == false)) {
                throw new UnknownFileException("Unknown file please provide a valid file");
            }
            runAwk commandLineDemo = new runAwk();
            commandLineDemo.runAwk(store, list, output);
        } else {
            System.out.println("-------Help mode-------");
            System.out.println("/i - interactive mode");
            System.out.println("/i /o - interactive mode with output filename");
            System.out.println("/p - parameter mode requires 2 input filenames");
            System.out.println("    after the mode selection.");
            System.out.println("/p /o - parameter mode requires 2 input filenames");
            System.out.println("   and 1 output filename after the mode selection.");

        }

    }
    */
    
     /**
     * @param store
     * @param storeFile
     * @param list
     * @param listFile
     
     * @param output
     * @return 
     
     */
    public void runAwk(String store,File storeFile, String list,File listFile, String output) {
        String s;
        String s2;
        String stringOutput;
        ArrayList<String> stringLog1;
        ArrayList<String> stringLog2;
        stringLog1 = new ArrayList<>();
        stringLog2 = new ArrayList<>();
        
        try {

            if (output.length() == 0) {
                String command = "awk {print}".concat(" " + store);
                String command2 = "awk {print}".concat(" " + list) ;
                Runtime rt = Runtime.getRuntime();
                Process p = rt.exec(command, null, storeFile);
                        
                Process p2 = rt.exec(command2,null,listFile.getParentFile());
                BufferedReader br = new BufferedReader(
                        new InputStreamReader(p.getInputStream()));
                BufferedReader br2 = new BufferedReader(
                        new InputStreamReader(p2.getInputStream()));

                while ((s = br.readLine()) != null) {
                    stringLog1.add(s);
                }
                while ((s2 = br2.readLine()) != null) {
                    stringLog2.add(s2);
                }
            }
            if (output.length() > 0) {
              String command =  "awk {print}".concat(" " + store);
                String command2 =  "awk {print}".concat(" " + list);
               
                Runtime rt = Runtime.getRuntime();

                Process p = rt.exec(command,null, storeFile.getParentFile());
                      
                Process p2 = rt.exec(command2,null,listFile.getParentFile());
                BufferedReader br = new BufferedReader(
                        new InputStreamReader(p.getInputStream()));
                BufferedReader br2 = new BufferedReader(
                        new InputStreamReader(p2.getInputStream()));

               while ((s = br.readLine()) != null) {
                    stringLog1.add(s);
                }

                while ((s2 = br2.readLine()) != null) {
                    stringLog2.add(s2);
                }

            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println(e.getLocalizedMessage());
        }
        boolean[][] contains = new boolean[stringLog1.size()][stringLog2.size()];
        int listCount = 0;
        String[] strings1;
        String[] strings2;
        double total = 0.0;
        int j = 0;
        int count = 0;
        boolean found;
         b1 = new Boolean[stringLog1.size()];
        Arrays.fill(b1, false);
        for (int i = 0; i < stringLog1.size(); i++) {

            found = false;

            for (int i2 = 0; i2 < stringLog2.size(); i2++) {
                
                strings2 = stringLog2.get(i2).split(" ");
                contains[i][i2] = stringLog1.get(i).contains(strings2[0]);
                if (contains[i][i2] == true) {
                    
                    strings1 = stringLog1.get(i).split(" ");
                   int t = Integer.parseInt(strings1[1]);
                    if(b1[(t-1)] == false){
                        b1[(t-1)] = true;
                    }
                    listCount++;
                    double x = Double.parseDouble(strings1[3]);

                    double y = Double.parseDouble(strings2[1]);
                    double item = x * y;
                    total = total + item;

                    stringOutput = ("Item: " + strings2[0] + " Aisle: " + strings1[1] 
                             + " Quantity requested: " + strings2[1] + " Cost per unit: " + strings1[3] + " Price for listed request: " + String.format("%.2f", item)
                            + " Running Total: " + String.format("%.2f", total));
                    if (output.isEmpty() == true) {
                        System.out.println(stringOutput);
                        count++;
                        System.out.println(count);
                        if (stringLog2.size() == listCount) {
                            System.out.println("All items are in store");
                            System.out.println("Total: $" + String.format("%.2f", total));

                        } else if ((count == stringLog2.size())) {
                            System.out.println("All items are not in store");
                            System.out.println("Total of available items: $" + String.format("%.2f", total));
                        }
                    } else {

                        try {
                            FileWriter fw;
                            
                            if (j == 0) {
                                fw = new FileWriter(listFile.getParent() + "/" +output);
                                fw.write(stringOutput);
                                j++;
                            }

                            fw = new FileWriter(listFile.getParent() + "/" +output, true);
                            
                            fw.append(stringOutput);
                            fw.append(System.lineSeparator());
                            if (stringLog2.size() == listCount) {
                                fw.append("All items are in store");
                                fw.append(System.lineSeparator());
                                fw.append("Total: $" + String.format("%.2f", total));
                                fw.append(System.lineSeparator());
                                count++;
                            } else if (count == stringLog2.size()) {
                                fw.append("All items are not in store");
                                fw.append(System.lineSeparator());
                                fw.append("Total of available items: $" + String.format("%.2f", total));
                                fw.append(System.lineSeparator());
                            }

                            fw.close();
                        } catch (Exception e) {

                        }
                    }
                }
            }
        }
        
    }
    public Boolean[] getAisles(){
        return(b1);
    }
}
