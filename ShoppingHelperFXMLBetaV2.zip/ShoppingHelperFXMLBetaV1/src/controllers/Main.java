/*
 * File: Main.java
 * Author: Tyler Pierce tpierce7@uab.edu
 * Assignment:  ShoppingHelperFXML - EE333 Fall 2018
 * Vers: 1.0.0 12/05/2018 ATP - initial coding
 *
 * Credits:  (if any for sections of code)
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package controllers;


/**
 *
 * @author Tyler Pierce tpierce7@uab.edu
 * @author Gavin Matthews gm97@uab.edu
 */
public class Main  {
  
    /**
     * @param args the command line arguments
     */
public static void main(String[] args) {
       
   
    }
}
