/*
 * File: mainController.java
 * Author: Tyler Pierce tpierce7@uab.edu
 * Assignment:  ShoppingHelperFXML - EE333 Fall 2018
 * Vers: 1.0.0 12/05/2018 ATP - initial coding
 *
 * Credits:  (if any for sections of code)
 */
 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import java.awt.Desktop;
import java.io.File;
import java.nio.file.Path;
import javafx.event.*;
import javafx.fxml.*;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;

/**
 *
 * @author Tyler Pierce tpierce7@uab.edu
 */
public class mainController {

    @FXML
    private ComboBox selectStoreComboBox;
    @FXML
    private Button viewInventoryButton;
    @FXML
    private Button importListButton;
    @FXML
    private Button createListButton;
    @FXML
    private Button goButton;

    final FileChooser fileChooser = new FileChooser();

    private static Desktop desktop = Desktop.getDesktop();

    
    
    private String listName;
    private Path listPath;
    private String storeName;
    private Path storePath;
    private String outputName = "output.txt";
    private File listFile;
    private File storeFile;
    private File outputFile;
    private Boolean[] b1;
    // private final AppModel model;

    // Event listener on ComboBox[#selectStoreComboBox].onAction
    @FXML
    public void selectStore(ActionEvent event) {
        //Code for storing the selected choice and enabling buttons
      storeName =  selectStoreComboBox.getValue().toString() + ".txt";
      storeFile = new File("C:\\Users\\Gavin Matthews\\Desktop\\Work\\3Junior\\First Semester\\EE333\\ShoppingHelperFXMLBetaV1\\store\\Target.txt"); 
    }

    // Event listener on Button[#viewInventoryButton].onAction
    @FXML
    public void viewInventory(ActionEvent event) {
        AppModel.setPane(1);
    }

    // Event listener on Button[#importListButton].onAction
    @FXML
    public void importList(ActionEvent event) {
        //Code that pulls up file explorer

        File file = fileChooser.showOpenDialog(importListButton.getScene().getWindow());
        if (file != null) {
            openFile(file);
        }
        AppModel.setPane(1);
    }

    // Event listener on Button[#createListButton].onAction
    @FXML
    public void createList(ActionEvent event) {
        //Just move to shoppingListPage
        AppModel.setPane(1);
    }

    // Event listener on Button[#goButton].onAction
    @FXML
    public void go(ActionEvent event) {
        // ??? Not really sure what this is supposed to do...
        AppModel.awk.runAwk(storeName, storeFile, listName, listFile, outputName);
        AppModel.setPane(2);

    }

    public void initialize() {
        // All the junk like disabling and enabling buttons and stuff I guess
        selectStoreComboBox.setPromptText("Please Select Store...  ");
        //Populate
        ObservableList<String> store = FXCollections.observableArrayList();
        storeFile= new File(".//store");
        File[] storeFiles = storeFile.listFiles();

        for (int i = 0; i < storeFiles.length; i++) {
            if (storeFiles[i].isFile()) {
               int i2 = storeFiles[i].getName().indexOf(".");
                
                store.add(storeFiles[i].getName().substring(0, i2));
            } 
        }
        selectStoreComboBox.setItems(store);
    }

    public void openFile(File file) {

        listFile = file;
        listName = file.getName();
    }

    public static Boolean[] getAisles() {
        return (AppModel.awk.getAisles());
    }
}
