/*
 * File: Command_Line_Demo.java
 * Author: Gavin Matthews gm97@uab.edu
 * Assignment:  Command_Line_Demo - EE333 Fall 2018
 * Vers: 1.0.0 11/01/2018 GAM - initial coding
 *
 * Credits:  (if any for sections of code)
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.util.Scanner;
import java.io.*;

/**
 *
 * @author Gavin Matthews gm97@uab.edu
 */
public class Command_Line_Demo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         if ((args.length == 1) && ("/i".equals(args[0]))){
             
            Scanner scanner = new Scanner(System.in);
            System.out.println("Which store would you like to select? ");
            String store = scanner.next();
            System.out.println("What is your grocery list?");
            String list = scanner.next();
            
            System.out.println(" awk {print} " + store);
            PipedWriter piw = new PipedWriter();
            
            
            try{
            FileWriter fw = new FileWriter("test.txt");
            fw.write(" awk {print} " + store);
            fw.close();
            }
            catch (Exception e){
                    System.out.println("error");
                    
       }
         }
        if ((args.length == 0)||((args.length == 1)&& ("/h".equals(args[0])))){
            System.out.println("Help mode");
        }
                
    

}
}