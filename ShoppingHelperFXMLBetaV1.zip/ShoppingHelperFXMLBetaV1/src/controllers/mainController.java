/*
 * File: mainController.java
 * Author: Tyler Pierce tpierce7@uab.edu
 * Assignment:  ShoppingHelperFXML - EE333 Fall 2018
 * Vers: 1.0.0 12/05/2018 ATP - initial coding
 *
 * Credits:  (if any for sections of code)
 */
 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import java.awt.Desktop;
import java.io.File;
import java.nio.file.Path;
import javafx.event.*;
import javafx.fxml.*;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
/**
 *
 * @author Tyler Pierce tpierce7@uab.edu
 */
public class mainController {

    @FXML
    private ComboBox selectStoreComboBox;
    @FXML
    private Button viewInventoryButton;
    @FXML
    private Button importListButton;
    @FXML
    private Button createListButton;
    @FXML
    private Button goButton;

    final FileChooser fileChooser = new FileChooser();

    private static Desktop desktop = Desktop.getDesktop();

    private static runAwk awk = new runAwk(); // call to create backend object
    private String listName;
    private Path listPath;
    private String storeName = "Target.txt";
    private Path storePath;
    private String outputName = "output.txt";
    private Path outputPath;
    private File listFile;
    private File storeFile;
    private File outputFile;
    private Boolean[] b1;
   // private final AppModel model;
    
    // Event listener on ComboBox[#selectStoreComboBox].onAction
    @FXML
    private Circle aisleOneCircle,aisleTwoCircle,aisleThreeCircle,aisleFourCircle,aisleFiveCircle,aisleSixCircle;
    @FXML
    private Text aisleOneText,aisleTwoText,aisleThreeText,aisleFourText,aisleFiveText,aisleSixText;
    @FXML
    public void selectStore(ActionEvent event) {
        //Code for storing the selected choice and enabling buttons
    }

    // Event listener on Button[#viewInventoryButton].onAction
    @FXML
    public void viewInventory(ActionEvent event) {
        AppModel.setPane(1);
    }

    // Event listener on Button[#importListButton].onAction
    @FXML
    public void importList(ActionEvent event) {
        //Code that pulls up file explorer

        File file = fileChooser.showOpenDialog(importListButton.getScene().getWindow());
        if (file != null) {
            openFile(file);
        }
    }

    // Event listener on Button[#createListButton].onAction
    @FXML
    public void createList(ActionEvent event) {
        //Just move to shoppingListPage
        AppModel.setPane(1);
    }

    // Event listener on Button[#goButton].onAction
    @FXML
    public void go(ActionEvent event) {
        // ??? Not really sure what this is supposed to do...
       awk.runAwk(storeName, storeFile, listName, listFile, outputName);
        AppModel.setPane(2);
        
    }

    public void initialize() {
        // All the junk like disabling and enabling buttons and stuff I guess
       
    }

    public void openFile(File file) {

        listFile = file;
        listName = file.getName();
        storeFile = file.getParentFile();
    }
    public static Boolean[] getAisles(){
        return(awk.getAisles());
    }
}
